package com.lq.bank.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

	@GetMapping
	public List<Map> listOfAllAccounts() {
		List<Map> accountList = new ArrayList<Map>();
		
		Map<String,Object> a1 = new HashMap();
		a1.put("Account 1", "Checking");
		a1.put("Account 2", "Savings");
		a1.put("customer", "John Doe");
		
		Map<String,Object> a2 = new HashMap();
		a2.put("Account 1", "Checking");
		a2.put("Account 2", "Savings");
		a2.put("customer", "Jane Doe");
		
		accountList.add(a1);
		accountList.add(a2);
		return accountList;
		
	}
	
	@GetMapping("/{id}")
	public List<Map> getAccountInfo( @PathVariable("id") int userId ) {
		List<Map> accountList = new ArrayList<Map>();
		Map<String,Object> a1 = new HashMap();
		
		a1.put("customer", "John Doe");
		a1.put("checking balance", 85000);
		a1.put("savings balance", 175000);
		a1.put("id", userId);
		
		accountList.add(a1);
		
		return accountList;
	}
	
	@PostMapping
	public String createNewAccount() {
		return "Soon Create";
	}
	
	@PutMapping("/{id}")
	public String updateAccount() {
		return "Soon Update";
	}
	
	@DeleteMapping("/{id}")
	public String deleteAccount() {
		return "Soon Delete";
	}

	
}
